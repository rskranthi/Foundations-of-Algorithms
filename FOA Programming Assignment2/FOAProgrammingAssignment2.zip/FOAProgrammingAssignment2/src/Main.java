
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.net.*;
import java.util.*;

public class Main {

	private Main()
    {
    } 

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		Scanner sc;
		
		while(true)
		{
					
		System.out.println("SELECT YOUR CHOICE 1.CONSOLE 2.TEXTFILE 3.EXIT ");
    	sc=new Scanner(System.in);
    	int players=0;
    	try{
    		PrintStream stdout = System.out;// Declared to hold current console as output
    	switch(sc.nextInt())
    	{
    	
    	case 1 :int[] values=new int[40];
    			int index=0;
    			players=sc.nextInt(); 
    			Matches m = new Matches();
    			//if(players%2==0)m.matchSchedulerEven(players,stdout);
    			//else 
    			m.matchScheduler(players,stdout);
    		    break;
    	           	
    	case 2 :File file = new File(args[0]);
    		
    		
    			sc = new Scanner(file);
    			
    			while(sc.hasNext()){
    				//System.setOut(stdout);	
    			players=sc.nextInt();
    			
    			Matches m1 = new Matches();
    	    	
    	    	m1.matchScheduler(players,stdout);
    	    	//System.out.println(players);
    	    	}
    			System.setOut(stdout);
    			break;
    	case 3: System.exit(0);
    	default: System.out.println("Please select valid input");
    	   			
	}
    	}catch (Exception e)
    	{
    		System.out.println("Exception message: " + e);
    	}
    	
    	
    	
    	
    	
}
	}
}



	
