import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;


public class Matches {
	
	
	
	
	public void matchScheduler(int players,PrintStream outputSelection){
		int n = players;
		int days = n%2==0?players-1:players;
		int[] playerArray = new int[days];
		for(int i=0;i<days;i++)
			playerArray[i]=i+1;
		
		
		for(int i=0;i<days;i++){
			HashMap<Integer,String> tm = new HashMap<Integer,String>();
			for(int j=0;j<playerArray.length/2;j++){
				
				tm.put(playerArray[j],Integer.toString(playerArray[playerArray.length-j-1]));
				tm.put(playerArray[playerArray.length-j-1],Integer.toString(playerArray[j]));
			}
			
			
			//Printing to console
			
			
			if(n%2!=0)
				tm.put(playerArray[playerArray.length/2], "-");
			else{
				tm.put(playerArray[playerArray.length/2], Integer.toString(n));
				tm.put(n,Integer.toString(playerArray[playerArray.length/2]));
			}
			
			if(players<11){
				System.setOut(outputSelection);
				System.out.print((i+1)+":");
				for(int j=1;j<=n;j++){
					if(j==n)System.out.print(tm.get(j));
					else System.out.print(tm.get(j)+":");}
			System.out.println();
			}
			
			else
			{
				try{
				File file = new File("output.txt");
				FileOutputStream fis;
				
					
					fis = new FileOutputStream(file,true);
					
					PrintStream out = new PrintStream(fis);
					
					System.setOut(out);
					System.out.print((i+1)+":");
					for(int j=1;j<=n;j++){
						if(j==n)System.out.print(tm.get(j));
						else System.out.print(tm.get(j)+":");}
					
					System.out.println();
					if(i==days-1){
						for(int hashes=0;hashes<2*players;hashes++)
							System.out.print("#");
						System.out.println();
					}
					out.close();
					fis.close();
					
					System.setOut(outputSelection);
				} 
				
				catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			//Player Array Rotation
			int last=playerArray[playerArray.length-1];
			for(int p=playerArray.length-1;p>0;p--)
			{
				
				playerArray[p]=playerArray[p-1];
			}
			playerArray[0]=last;
			
			
				
		}
		
	}
	
	
	}

